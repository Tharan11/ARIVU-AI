const mongoose = require('mongoose');

const memorySchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  // Learning progress
  learningProgress: {
    topics: [{
      name: String,
      level: { type: String, enum: ['beginner', 'intermediate', 'advanced'], default: 'beginner' },
      sessionsCount: { type: Number, default: 0 },
      lastStudied: Date
    }],
    totalSessions: { type: Number, default: 0 },
    streakDays: { type: Number, default: 0 },
    lastActiveDate: Date
  },
  // User preferences
  preferences: {
    language: { type: String, default: 'mixed' },
    responseStyle: { type: String, enum: ['simple', 'detailed', 'academic'], default: 'detailed' },
    interests: [String],
    subjectAreas: [String]
  },
  // Goals
  goals: [{
    title: String,
    description: String,
    targetDate: Date,
    progress: { type: Number, default: 0, min: 0, max: 100 },
    isCompleted: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now }
  }],
  // Recurring topics (extracted from conversations)
  recurringTopics: [{
    topic: String,
    frequency: { type: Number, default: 1 },
    lastMentioned: { type: Date, default: Date.now }
  }],
  // Custom notes the AI remembers
  notes: [{
    content: String,
    category: String,
    createdAt: { type: Date, default: Date.now }
  }]
}, {
  timestamps: true
});

module.exports = mongoose.model('Memory', memorySchema);