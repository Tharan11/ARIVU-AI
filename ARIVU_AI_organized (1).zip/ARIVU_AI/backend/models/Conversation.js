const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  role: { type: String, enum: ['user', 'assistant'], required: true },
  content: { type: String, required: true },
  language: { type: String, default: 'mixed' },
  audioUrl: { type: String, default: '' },
  timestamp: { type: Date, default: Date.now }
});

const conversationSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  title: {
    type: String,
    default: 'New Conversation'
  },
  messages: [messageSchema],
  model: {
    type: String,
    default: 'gemini'
  },
  topic: {
    type: String,
    default: 'general'
  },
  language: {
    type: String,
    enum: ['tamil', 'english', 'mixed'],
    default: 'mixed'
  },
  isArchived: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Conversation', conversationSchema);