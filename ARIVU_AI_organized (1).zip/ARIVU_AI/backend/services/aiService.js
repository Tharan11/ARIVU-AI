const { GoogleGenerativeAI } = require('@google/generative-ai');
const Groq = require('groq-sdk');
const OpenAI = require('openai');

const geminiClient = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const groqClient = new Groq({ apiKey: process.env.GROQ_API_KEY });
const openaiClient = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const ARIVU_SYSTEM_PROMPT = `You are ARIVU (அறிவு), an advanced AI assistant specifically designed for Tamil speakers and learners. 

CORE IDENTITY:
- Name: ARIVU (means "Knowledge/Intelligence" in Tamil)
- You understand Tamil, English, and code-switched Tamil-English (Tanglish)
- You celebrate Tamil culture, literature, history, and civilization
- You are built for Tamil Nadu students, professionals, and cultural enthusiasts

CAPABILITIES:
- Answer in Tamil or English or both depending on what the user writes
- Help with TNPSC exam preparation, Tamil literature (Sangam, Thirukkural), school subjects
- Explain technical concepts using Tamil analogies and examples
- Provide culturally relevant examples from Tamil Nadu

WHY ARIVU OVER CHATGPT/GEMINI:
- Deep Tamil cultural context built in
- Understands Tanglish naturally
- TNPSC / Tamil Nadu curriculum focus
- Local analogies and examples
- Tamil script support
- Memory of your learning journey

RESPONSE STYLE:
- Be warm, encouraging, and teacher-like (ஆசிரியர் style)
- Use Tamil proverbs when relevant
- Keep responses clear and structured
- For technical topics, provide step-by-step explanations

Remember: You exist to make knowledge (அறிவு) accessible to every Tamil speaker.`;

// ── Gemini Chat ──
const chatWithGemini = async (messages, userMemory = null) => {
  try {
    const model = geminiClient.getGenerativeModel({ model: 'gemini-pro' });

    let systemContext = ARIVU_SYSTEM_PROMPT;
    if (userMemory) {
      systemContext += `\n\nUSER CONTEXT (remember this):\n${JSON.stringify(userMemory, null, 2)}`;
    }

    const history = messages.slice(0, -1).map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));

    const chat = model.startChat({
      history: [
        { role: 'user', parts: [{ text: systemContext }] },
        { role: 'model', parts: [{ text: 'Understood. I am ARIVU, ready to help Tamil speakers with knowledge and wisdom.' }] },
        ...history
      ]
    });

    const lastMessage = messages[messages.length - 1];
    const result = await chat.sendMessage(lastMessage.content);
    return result.response.text();
  } catch (err) {
    throw new Error(`Gemini error: ${err.message}`);
  }
};

// ── Groq Chat ──
const chatWithGroq = async (messages, userMemory = null) => {
  try {
    let systemContent = ARIVU_SYSTEM_PROMPT;
    if (userMemory) {
      systemContent += `\n\nUSER CONTEXT:\n${JSON.stringify(userMemory, null, 2)}`;
    }

    const formattedMessages = [
      { role: 'system', content: systemContent },
      ...messages.map(m => ({ role: m.role, content: m.content }))
    ];

    const completion = await groqClient.chat.completions.create({
      messages: formattedMessages,
      model: 'llama3-70b-8192',
      temperature: 0.7,
      max_tokens: 2048
    });

    return completion.choices[0]?.message?.content || '';
  } catch (err) {
    throw new Error(`Groq error: ${err.message}`);
  }
};

// ── OpenAI Chat ──
const chatWithOpenAI = async (messages, userMemory = null) => {
  try {
    let systemContent = ARIVU_SYSTEM_PROMPT;
    if (userMemory) {
      systemContent += `\n\nUSER CONTEXT:\n${JSON.stringify(userMemory, null, 2)}`;
    }

    const formattedMessages = [
      { role: 'system', content: systemContent },
      ...messages.map(m => ({ role: m.role, content: m.content }))
    ];

    const completion = await openaiClient.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: formattedMessages,
      temperature: 0.7,
      max_tokens: 2048
    });

    return completion.choices[0]?.message?.content || '';
  } catch (err) {
    throw new Error(`OpenAI error: ${err.message}`);
  }
};

// ── Smart Router ──
const getAIResponse = async (messages, model = 'gemini', userMemory = null) => {
  switch (model) {
    case 'gemini': return await chatWithGemini(messages, userMemory);
    case 'groq': return await chatWithGroq(messages, userMemory);
    case 'openai': return await chatWithOpenAI(messages, userMemory);
    default: return await chatWithGemini(messages, userMemory);
  }
};

module.exports = { getAIResponse, ARIVU_SYSTEM_PROMPT };