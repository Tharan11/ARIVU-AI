const express = require('express');
const { protect } = require('../middleware/auth');
const { getAIResponse } = require('../services/aiService');

const router = express.Router();

// POST /api/voice/respond - Get AI response for voice input
router.post('/respond', protect, async (req, res) => {
  try {
    const { transcript, language = 'ta', conversationHistory = [] } = req.body;

    if (!transcript) {
      return res.status(400).json({ error: 'Voice transcript is required' });
    }

    // Build message history
    const messages = [
      ...conversationHistory.slice(-10),
      { role: 'user', content: transcript }
    ];

    // Add voice-specific instruction to get concise responses
    const voiceMessages = [
      {
        role: 'user',
        content: `[Voice Mode - Please give a concise, spoken-word friendly response in ${language === 'ta' ? 'Tamil' : 'English'}. Avoid markdown, bullet points, or code blocks unless essential.]\n\n${transcript}`
      }
    ];

    const response = await getAIResponse(voiceMessages, 'gemini');

    res.json({
      response,
      language,
      transcript
    });
  } catch (err) {
    res.status(500).json({ error: 'Voice response failed', details: err.message });
  }
});

// GET /api/voice/tts-config - Get TTS configuration for frontend
router.get('/tts-config', protect, (req, res) => {
  // Web Speech API config hints for Tamil
  res.json({
    tamilVoiceHints: {
      lang: 'ta-IN',
      fallbackLang: 'en-IN',
      rate: 0.9,
      pitch: 1.0,
      volume: 1.0
    },
    sttConfig: {
      continuous: false,
      interimResults: true,
      lang: 'ta-IN',
      maxAlternatives: 3
    }
  });
});

module.exports = router;