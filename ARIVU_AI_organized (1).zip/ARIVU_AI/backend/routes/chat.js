const express = require('express');
const { protect } = require('../middleware/auth');
const Conversation = require('../models/Conversation');
const Memory = require('../models/Memory');
const { getAIResponse } = require('../services/aiService');

const router = express.Router();

// POST /api/chat/message - Send a message
router.post('/message', protect, async (req, res) => {
  try {
    const { message, conversationId, model = 'gemini', language = 'mixed' } = req.body;

    if (!message || message.trim() === '') {
      return res.status(400).json({ error: 'Message cannot be empty' });
    }

    // Deduct credit
    if (req.user.credits <= 0) {
      return res.status(402).json({ error: 'No credits remaining. Please upgrade your plan.' });
    }

    // Load or create conversation
    let conversation;
    if (conversationId) {
      conversation = await Conversation.findOne({ _id: conversationId, userId: req.user._id });
      if (!conversation) return res.status(404).json({ error: 'Conversation not found' });
    } else {
      conversation = await Conversation.create({
        userId: req.user._id,
        title: message.substring(0, 50),
        model,
        language
      });
    }

    // Add user message
    conversation.messages.push({ role: 'user', content: message, language });

    // Load user memory for context
    const memory = await Memory.findOne({ userId: req.user._id });
    const memoryContext = memory ? {
      preferences: memory.preferences,
      recurringTopics: memory.recurringTopics?.slice(0, 5),
      goals: memory.goals?.filter(g => !g.isCompleted).slice(0, 3)
    } : null;

    // Get recent messages for context (last 20)
    const recentMessages = conversation.messages.slice(-20).map(m => ({
      role: m.role,
      content: m.content
    }));

    // Get AI response
    const aiResponse = await getAIResponse(recentMessages, model, memoryContext);

    // Add assistant message
    conversation.messages.push({ role: 'assistant', content: aiResponse, language });

    // Auto-generate title if first message
    if (conversation.messages.length === 2) {
      conversation.title = message.substring(0, 60) + (message.length > 60 ? '...' : '');
    }

    await conversation.save();

    // Update memory with topics (async, don't await)
    updateMemoryTopics(req.user._id, message).catch(console.error);

    // Deduct credit (async)
    req.user.credits -= 1;
    req.user.save({ validateBeforeSave: false }).catch(console.error);

    res.json({
      conversationId: conversation._id,
      response: aiResponse,
      creditsLeft: req.user.credits
    });
  } catch (err) {
    console.error('Chat error:', err);
    res.status(500).json({ error: 'Failed to get response', details: err.message });
  }
});

// GET /api/chat/conversations - List all conversations
router.get('/conversations', protect, async (req, res) => {
  try {
    const conversations = await Conversation.find({
      userId: req.user._id,
      isArchived: false
    })
    .select('title model language createdAt updatedAt')
    .sort({ updatedAt: -1 })
    .limit(50);

    res.json({ conversations });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch conversations' });
  }
});

// GET /api/chat/conversations/:id - Get single conversation
router.get('/conversations/:id', protect, async (req, res) => {
  try {
    const conversation = await Conversation.findOne({
      _id: req.params.id,
      userId: req.user._id
    });

    if (!conversation) return res.status(404).json({ error: 'Conversation not found' });

    res.json({ conversation });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch conversation' });
  }
});

// DELETE /api/chat/conversations/:id
router.delete('/conversations/:id', protect, async (req, res) => {
  try {
    await Conversation.findOneAndDelete({ _id: req.params.id, userId: req.user._id });
    res.json({ message: 'Conversation deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete conversation' });
  }
});

// Helper: Extract topics from message
async function updateMemoryTopics(userId, message) {
  const keywords = message.toLowerCase().split(/\s+/).filter(w => w.length > 4);
  const memory = await Memory.findOne({ userId });
  if (!memory) return;

  keywords.forEach(word => {
    const existing = memory.recurringTopics.find(t => t.topic === word);
    if (existing) {
      existing.frequency += 1;
      existing.lastMentioned = new Date();
    } else if (memory.recurringTopics.length < 50) {
      memory.recurringTopics.push({ topic: word, frequency: 1 });
    }
  });

  memory.learningProgress.totalSessions += 1;
  await memory.save();
}

module.exports = router;