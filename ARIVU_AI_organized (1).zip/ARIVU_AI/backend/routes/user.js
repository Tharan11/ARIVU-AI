const express = require('express');
const { protect } = require('../middleware/auth');
const User = require('../models/User');

const router = express.Router();

// GET /api/user/profile
router.get('/profile', protect, async (req, res) => {
  res.json({ user: req.user });
});

// PATCH /api/user/profile
router.patch('/profile', protect, async (req, res) => {
  try {
    const { name, preferredLanguage, avatar } = req.body;
    const updates = {};
    if (name) updates.name = name;
    if (preferredLanguage) updates.preferredLanguage = preferredLanguage;
    if (avatar) updates.avatar = avatar;

    const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true, runValidators: true });
    res.json({ user });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

// GET /api/user/credits
router.get('/credits', protect, async (req, res) => {
  const user = await User.findById(req.user._id).select('credits plan');
  res.json({ credits: user.credits, plan: user.plan });
});

module.exports = router;