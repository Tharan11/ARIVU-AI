const express = require('express');
const { protect } = require('../middleware/auth');
const Memory = require('../models/Memory');

const router = express.Router();

// GET /api/memory - Get user memory
router.get('/', protect, async (req, res) => {
  try {
    let memory = await Memory.findOne({ userId: req.user._id });
    if (!memory) {
      memory = await Memory.create({ userId: req.user._id });
    }
    res.json({ memory });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch memory' });
  }
});

// POST /api/memory/goal - Add a goal
router.post('/goal', protect, async (req, res) => {
  try {
    const { title, description, targetDate } = req.body;
    if (!title) return res.status(400).json({ error: 'Goal title is required' });

    const memory = await Memory.findOne({ userId: req.user._id });
    memory.goals.push({ title, description, targetDate });
    await memory.save();

    res.json({ message: 'Goal added', goals: memory.goals });
  } catch (err) {
    res.status(500).json({ error: 'Failed to add goal' });
  }
});

// PATCH /api/memory/goal/:goalId - Update goal progress
router.patch('/goal/:goalId', protect, async (req, res) => {
  try {
    const { progress, isCompleted } = req.body;
    const memory = await Memory.findOne({ userId: req.user._id });

    const goal = memory.goals.id(req.params.goalId);
    if (!goal) return res.status(404).json({ error: 'Goal not found' });

    if (progress !== undefined) goal.progress = progress;
    if (isCompleted !== undefined) goal.isCompleted = isCompleted;

    await memory.save();
    res.json({ message: 'Goal updated', goal });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update goal' });
  }
});

// POST /api/memory/note - Add a note
router.post('/note', protect, async (req, res) => {
  try {
    const { content, category } = req.body;
    if (!content) return res.status(400).json({ error: 'Note content required' });

    const memory = await Memory.findOne({ userId: req.user._id });
    memory.notes.push({ content, category: category || 'general' });
    await memory.save();

    res.json({ message: 'Note saved', notes: memory.notes });
  } catch (err) {
    res.status(500).json({ error: 'Failed to save note' });
  }
});

// PATCH /api/memory/preferences - Update preferences
router.patch('/preferences', protect, async (req, res) => {
  try {
    const { language, responseStyle, interests, subjectAreas } = req.body;

    const memory = await Memory.findOne({ userId: req.user._id });
    if (language) memory.preferences.language = language;
    if (responseStyle) memory.preferences.responseStyle = responseStyle;
    if (interests) memory.preferences.interests = interests;
    if (subjectAreas) memory.preferences.subjectAreas = subjectAreas;

    await memory.save();
    res.json({ message: 'Preferences updated', preferences: memory.preferences });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update preferences' });
  }
});

module.exports = router;
{
  "name": "arivu-ai-frontend",
  "version": "1.0.0",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.21.0",
    "zustand": "^4.4.7",
    "axios": "^1.6.2",
    "react-hot-toast": "^2.4.1",
    "lucide-react": "^0.303.0",
    "framer-motion": "^10.17.4",
    "react-markdown": "^9.0.1",
    "remark-gfm": "^4.0.0",
    "react-syntax-highlighter": "^15.5.0",
    "date-fns": "^3.0.6"
  },
  "devDependencies": {
    "@types/react": "^18.2.43",
    "@types/react-dom": "^18.2.17",
    "@vitejs/plugin-react": "^4.2.1",
    "autoprefixer": "^10.4.16",
    "postcss": "^8.4.32",
    "tailwindcss": "^3.4.0",
    "vite": "^5.0.8"
  }
}
{
  "name": "arivu-ai-backend",
  "version": "1.0.0",
  "description": "ARIVU AI - Tamil AI Platform Backend",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "mongoose": "^8.0.0",
    "dotenv": "^16.3.1",
    "cors": "^2.8.5",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "express-rate-limit": "^7.1.5",
    "helmet": "^7.1.0",
    "morgan": "^1.10.0",
    "@google/generative-ai": "^0.2.1",
    "groq-sdk": "^0.3.3",
    "openai": "^4.20.1",
    "axios": "^1.6.2",
    "multer": "^1.4.5-lts.1",
    "express-validator": "^7.0.1",
    "compression": "^1.7.4",
    "node-cache": "^5.1.2"
  },
  "devDependencies": {
    "nodemon": "^3.0.2"
  }
}
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {}
  }
};