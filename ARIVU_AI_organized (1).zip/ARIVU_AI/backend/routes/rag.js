const express = require('express');
const { protect } = require('../middleware/auth');
const { getAIResponse } = require('../services/aiService');

const router = express.Router();

// Tamil Knowledge Base - built-in cultural data
const TAMIL_KNOWLEDGE_BASE = {
  thirukkural: {
    description: "Thirukkural - 1330 couplets by Thiruvalluvar covering ethics, governance, and love",
    samples: [
      { kural: 1, tamil: "அகர முதல எழுத்தெல்லாம் ஆதி பகவன் முதற்றே உலகு", meaning: "All letters begin with 'A'; the world begins with God" },
      { kural: 391, tamil: "கல்லாதான் செல்வம் கலம் இல்லா நாவினுக்கு", meaning: "The wealth of an uneducated man is like words from a toothless mouth" }
    ]
  },
  sangam: {
    description: "Sangam Literature - Ancient Tamil poetry (300 BCE - 300 CE)",
    genres: ["Akam (love poetry)", "Puram (war & heroism)", "Tinai (landscapes & emotions)"],
    majorWorks: ["Purananuru", "Akananuru", "Natrinai", "Kuruntokai", "Tolkappiyam"]
  },
  tnpsc: {
    description: "TNPSC - Tamil Nadu Public Service Commission exam preparation",
    groups: ["Group 1 (IAS equivalent)", "Group 2 (Assistant Section Officer)", "Group 4 (VAO)"],
    subjects: ["Tamil", "General Knowledge", "Indian Constitution", "History", "Geography", "Science"]
  },
  tamilHistory: {
    dynasties: ["Chola", "Chera", "Pandya", "Pallava", "Nayak"],
    achievements: ["Brihadeeswarar Temple", "Naval supremacy in Southeast Asia", "Sangam Academy", "Ponniyin Selvan era"]
  }
};

// POST /api/rag/query - Query Tamil knowledge base
router.post('/query', protect, async (req, res) => {
  try {
    const { query, category } = req.body;

    if (!query) return res.status(400).json({ error: 'Query is required' });

    // Find relevant knowledge
    let relevantContext = '';
    const queryLower = query.toLowerCase();

    if (queryLower.includes('kural') || queryLower.includes('thirukkural') || queryLower.includes('திருக்குறள்')) {
      relevantContext += `THIRUKKURAL CONTEXT: ${JSON.stringify(TAMIL_KNOWLEDGE_BASE.thirukkural)}\n\n`;
    }
    if (queryLower.includes('sangam') || queryLower.includes('சங்கம்') || queryLower.includes('ancient tamil')) {
      relevantContext += `SANGAM LITERATURE: ${JSON.stringify(TAMIL_KNOWLEDGE_BASE.sangam)}\n\n`;
    }
    if (queryLower.includes('tnpsc') || queryLower.includes('exam') || queryLower.includes('group')) {
      relevantContext += `TNPSC INFO: ${JSON.stringify(TAMIL_KNOWLEDGE_BASE.tnpsc)}\n\n`;
    }
    if (queryLower.includes('history') || queryLower.includes('chola') || queryLower.includes('dynasty')) {
      relevantContext += `TAMIL HISTORY: ${JSON.stringify(TAMIL_KNOWLEDGE_BASE.tamilHistory)}\n\n`;
    }

    // If no specific match, use all knowledge
    if (!relevantContext) {
      relevantContext = `GENERAL TAMIL KNOWLEDGE: ${JSON.stringify(TAMIL_KNOWLEDGE_BASE)}\n\n`;
    }

    const augmentedMessage = [{
      role: 'user',
      content: `Using the following Tamil knowledge base:\n\n${relevantContext}\n\nAnswer this question: ${query}\n\nProvide accurate, culturally rich information based on the knowledge base above.`
    }];

    const response = await getAIResponse(augmentedMessage, 'gemini');

    res.json({ response, category: category || 'general', query });
  } catch (err) {
    res.status(500).json({ error: 'RAG query failed', details: err.message });
  }
});

// GET /api/rag/categories - Get available knowledge categories
router.get('/categories', protect, (req, res) => {
  res.json({
    categories: [
      { id: 'thirukkural', name: 'Thirukkural', nameInTamil: 'திருக்குறள்', description: '1330 couplets of wisdom' },
      { id: 'sangam', name: 'Sangam Literature', nameInTamil: 'சங்க இலக்கியம்', description: 'Ancient Tamil poetry' },
      { id: 'tnpsc', name: 'TNPSC Preparation', nameInTamil: 'தேர்வு தயாரிப்பு', description: 'Exam study material' },
      { id: 'tamilHistory', name: 'Tamil History', nameInTamil: 'தமிழர் வரலாறு', description: 'Dynasties & achievements' }
    ]
  });
});

module.exports = router;