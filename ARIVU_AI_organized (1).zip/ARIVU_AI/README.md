# ARIVU AI — அறிவு

**Tamil AI Platform for Knowledge and Learning**

A full-stack AI chat application with Tamil language support, voice interaction, memory, and a knowledge base rooted in Tamil culture.

---

## Project Structure

```
ARIVU_AI/
├── frontend/               # React + Vite frontend
│   ├── public/
│   │   └── manifest.json
│   ├── src/
│   │   ├── components/
│   │   │   ├── chat/
│   │   │   │   ├── ChatInput.jsx
│   │   │   │   └── Message.jsx
│   │   │   ├── ui/
│   │   │   │   └── Sidebar.jsx
│   │   │   └── voice/
│   │   │       └── VoiceInput.jsx
│   │   ├── hooks/
│   │   │   └── useVoice.js
│   │   ├── pages/
│   │   │   ├── AuthPage.jsx
│   │   │   ├── ChatPage.jsx
│   │   │   ├── KnowledgePage.jsx
│   │   │   ├── MemoryPage.jsx
│   │   │   └── VoicePage.jsx
│   │   ├── services/
│   │   │   └── api.js
│   │   ├── store/
│   │   │   ├── authStore.js
│   │   │   └── chatStore.js
│   │   ├── styles/
│   │   │   └── index.css
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── index.html
│   ├── package.json
│   ├── postcss.config.js
│   ├── tailwind.config.js
│   └── vite.config.js
│
└── backend/                # Node.js + Express backend
    ├── middleware/
    │   └── auth.js
    ├── models/
    │   ├── Conversation.js
    │   ├── Memory.js
    │   └── User.js
    ├── routes/
    │   ├── auth.js
    │   ├── chat.js
    │   ├── memory.js
    │   ├── rag.js
    │   ├── user.js
    │   └── voice.js
    ├── services/
    │   └── aiService.js
    ├── server.js
    ├── package.json
    ├── .env
    └── .env.example
```

---

## Getting Started

### Backend

```bash
cd backend
npm install
cp .env.example .env   # fill in your API keys
npm run dev
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

---

## Features

- 🗣️ **Tamil Voice AI** — STT/TTS with Tamil language support
- 🧠 **AI Memory** — Persistent memory across conversations
- 📚 **Knowledge Base** — Thirukkural, Sangam literature, Tamil history
- 💬 **Multi-model Chat** — Gemini, Groq, OpenAI
- 🔐 **Auth** — JWT-based login/register
- 📱 **PWA** — Installable progressive web app

## Tech Stack

| Layer | Tech |
|-------|------|
| Frontend | React 18, Vite, Tailwind CSS, Framer Motion, Zustand |
| Backend | Node.js, Express, MongoDB (Mongoose) |
| AI | Google Gemini, Groq, OpenAI |
| Auth | JWT + bcryptjs |
