import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, Sparkles } from 'lucide-react';
import Message from '../components/chat/Message';
import ChatInput from '../components/chat/ChatInput';
import Sidebar from '../components/ui/Sidebar';
import useChatStore from '../store/chatStore';
import useVoice from '../hooks/useVoice';

const TypingIndicator = () => (
  <div className="flex gap-3">
    <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-purple-600 to-violet-700
                    flex items-center justify-center text-sm font-bold text-white flex-shrink-0">
      அ
    </div>
    <div className="glass-card px-4 py-3 message-ai">
      <div className="flex gap-1.5 items-center">
        <div className="w-1.5 h-1.5 rounded-full bg-purple-400 typing-dot" />
        <div className="w-1.5 h-1.5 rounded-full bg-purple-400 typing-dot" />
        <div className="w-1.5 h-1.5 rounded-full bg-purple-400 typing-dot" />
        <span className="text-xs text-gray-500 ml-1">ARIVU is thinking...</span>
      </div>
    </div>
  </div>
);

const WelcomeScreen = ({ onSendMessage }) => (
  <div className="flex flex-col items-center justify-center h-full text-center px-6">
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-purple-600 to-violet-700
                      flex items-center justify-center text-4xl font-black text-white font-orbitron
                      mb-6 mx-auto animate-glow-pulse">
        அ
      </div>
      <h2 className="text-2xl font-bold text-white mb-2 font-orbitron">ARIVU AI</h2>
      <p className="text-purple-400 font-tamil text-lg mb-6">அறிவே வல்லமை</p>
      <p className="text-gray-400 max-w-md text-sm leading-relaxed mb-8">
        Your Tamil AI companion for learning, culture, and knowledge.
        Ask anything in Tamil or English — from Thirukkural to TNPSC, from coding to culture.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-sm mx-auto text-left">
        {[
          { q: "திருக்குறளில் அறம் என்றால் என்ன?", tag: "Literature" },
          { q: "TNPSC Group 4 syllabus explain", tag: "Exam Prep" },
          { q: "Python functions in Tamil", tag: "Coding" },
          { q: "Tell me about Chola dynasty", tag: "History" }
        ].map(({ q, tag }) => (
          <div key={q} className="glass-card p-3 cursor-pointer hover:border-purple-500/40 transition-all" onClick={() => onSendMessage(q)}>
            <span className="text-xs text-purple-400 font-medium">{tag}</span>
            <p className="text-xs text-gray-300 mt-1 font-tamil">{q}</p>
          </div>
        ))}
      </div>
    </motion.div>
  </div>
);

const ChatPage = () => {
  const { messages, isTyping, activeConversation, sendMessage } = useChatStore();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [lastAIMessage, setLastAIMessage] = useState('');
  const [speakText, setSpeakText] = useState('');
  const messagesEndRef = useRef(null);
  const { speak } = useVoice();

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Track last AI message for voice
  useEffect(() => {
    const aiMsgs = messages.filter(m => m.role === 'assistant');
    if (aiMsgs.length > 0) {
      setLastAIMessage(aiMsgs[aiMsgs.length - 1].content);
    }
  }, [messages]);

  const handleSpeak = (text) => {
    setSpeakText(text);
    speak(text);
  };

  return (
    <div className="flex h-screen bg-ambient overflow-hidden">
      {/* Sidebar */}
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-arivu-border bg-arivu-dark/80 backdrop-blur-md">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-2 text-gray-400 hover:text-white hover:bg-white/5 rounded-xl transition-all"
          >
            <Menu size={20} />
          </button>

          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-purple-400" />
            <span className="text-sm font-medium text-gray-300">
              {activeConversation?.title || 'New Conversation'}
            </span>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto chat-scroll p-4 space-y-4">
          {messages.length === 0 ? (
            <WelcomeScreen onSendMessage={sendMessage} />
          ) : (
            <>
              <AnimatePresence initial={false}>
                {messages.map((msg, i) => (
                  <Message
                    key={i}
                    message={msg}
                    onSpeak={handleSpeak}
                    isLatestAI={msg.role === 'assistant' && i === messages.length - 1}
                  />
                ))}
              </AnimatePresence>

              {isTyping && <TypingIndicator />}
            </>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <ChatInput lastAIMessage={lastAIMessage} onSpeak={handleSpeak} />
      </div>
    </div>
  );
};

export default ChatPage;