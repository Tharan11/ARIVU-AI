import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, MicOff, Volume2, VolumeX, Globe, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import useVoice from '../hooks/useVoice';
import api from '../services/api';
import toast from 'react-hot-toast';

const VoicePage = () => {
  const navigate = useNavigate();
  const [conversation, setConversation] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const {
    isListening, isSpeaking, transcript, interimTranscript,
    voiceLanguage, isSupported, error,
    startListening, stopListening, speak, stopSpeaking, toggleLanguage
  } = useVoice();

  const prevTranscriptRef = useRef('');

  // When listening stops and we have a transcript
  const handleVoiceEnd = React.useCallback(async () => {
    if (!transcript || transcript === prevTranscriptRef.current) return;
    prevTranscriptRef.current = transcript;

    const userText = transcript;
    setConversation(prev => [...prev, { role: 'user', text: userText }]);
    setIsProcessing(true);

    try {
      const res = await api.post('/voice/respond', {
        transcript: userText,
        language: voiceLanguage === 'ta-IN' ? 'ta' : 'en',
        conversationHistory: conversation.slice(-6).map(m => ({
          role: m.role,
          content: m.text
        }))
      });

      const aiText = res.data.response;
      setConversation(prev => [...prev, { role: 'assistant', text: aiText }]);
      speak(aiText, voiceLanguage);
    } catch (err) {
      toast.error('Voice response failed');
    } finally {
      setIsProcessing(false);
    }
  }, [transcript, conversation, voiceLanguage, speak]);

  // Watch transcript completion
  React.useEffect(() => {
    if (!isListening && transcript && transcript !== prevTranscriptRef.current) {
      handleVoiceEnd();
    }
  }, [isListening, transcript, handleVoiceEnd]);

  const handleMicToggle = () => {
    if (isListening) {
      stopListening();
    } else {
      if (isSpeaking) stopSpeaking();
      startListening();
    }
  };

  return (
    <div className="min-h-screen bg-ambient flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b border-arivu-border">
        <button
          onClick={() => navigate('/chat')}
          className="p-2 text-gray-400 hover:text-white hover:bg-white/5 rounded-xl transition-all"
        >
          <ArrowLeft size={20} />
        </button>
        <div>
          <h1 className="text-white font-semibold">Voice Mode</h1>
          <p className="text-xs text-gray-500 font-tamil">குரல் உரையாடல்</p>
        </div>
        <div className="ml-auto">
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl glass-card text-sm text-gray-300 hover:text-white transition-all"
          >
            <Globe size={14} />
            <span className="font-tamil">{voiceLanguage === 'ta-IN' ? 'தமிழ்' : 'English'}</span>
          </button>
        </div>
      </div>

      {/* Main Voice UI */}
      <div className="flex-1 flex flex-col items-center justify-between p-6 max-w-lg mx-auto w-full">

        {/* ARIVU Avatar */}
        <div className="flex flex-col items-center mt-8 mb-6">
          <motion.div
            animate={
              isSpeaking
                ? { scale: [1, 1.05, 1], boxShadow: ['0 0 30px rgba(124,111,255,0.4)', '0 0 60px rgba(124,111,255,0.7)', '0 0 30px rgba(124,111,255,0.4)'] }
                : isListening
                ? { scale: [1, 1.03, 1], boxShadow: ['0 0 30px rgba(239,68,68,0.4)', '0 0 50px rgba(239,68,68,0.6)', '0 0 30px rgba(239,68,68,0.4)'] }
                : { scale: 1, boxShadow: '0 0 20px rgba(124,111,255,0.2)' }
            }
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-32 h-32 rounded-3xl bg-gradient-to-br from-purple-600 to-violet-700
                       flex items-center justify-center text-6xl font-black text-white font-orbitron"
          >
            அ
          </motion.div>

          <div className="mt-4 text-center">
            <p className="text-white font-semibold">ARIVU Voice</p>
            <p className="text-sm text-gray-500 mt-1">
              {isSpeaking ? '🔊 Speaking...' :
               isListening ? '🎙️ Listening...' :
               isProcessing ? '⏳ Thinking...' :
               '💬 Tap mic to speak'}
            </p>
          </div>
        </div>

        {/* Transcript Area */}
        <div className="w-full flex-1 overflow-y-auto chat-scroll space-y-3 mb-6 px-2">
          <AnimatePresence>
            {conversation.slice(-6).map((msg, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`${msg.role === 'user' ? 'text-right' : 'text-left'}`}
              >
                <div className={`inline-block max-w-[85%] px-4 py-3 rounded-2xl text-sm font-tamil leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-purple-600/30 text-white'
                    : 'glass-card message-ai text-gray-200'
                }`}>
                  {msg.text}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Interim transcript */}
          {isListening && interimTranscript && (
            <div className="text-right">
              <div className="inline-block px-4 py-2 rounded-2xl text-sm bg-purple-600/10 text-purple-300 italic font-tamil">
                {interimTranscript}...
              </div>
            </div>
          )}

          {isProcessing && (
            <div className="text-left">
              <div className="inline-flex gap-1 px-4 py-3 rounded-2xl glass-card">
                {[0, 1, 2].map(i => (
                  <div key={i} className="w-1.5 h-1.5 rounded-full bg-purple-400 typing-dot" style={{ animationDelay: `${i * 0.2}s` }} />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Controls */}
        {!isSupported ? (
          <div className="text-center py-6">
            <p className="text-gray-500 text-sm">Voice not supported in this browser.</p>
            <p className="text-gray-600 text-xs mt-1">Please use Chrome for voice features.</p>
          </div>
        ) : (
          <div className="flex items-center justify-center gap-6 pb-6">
            {/* Speaker toggle */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={isSpeaking ? stopSpeaking : undefined}
              className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${
                isSpeaking ? 'bg-blue-500/20 text-blue-400' : 'glass-card text-gray-500'
              }`}
            >
              {isSpeaking ? <VolumeX size={20} /> : <Volume2 size={20} />}
            </motion.button>

            {/* Main Mic Button */}
            <div className="relative">
              {isListening && (
                <>
                  <motion.div
                    className="absolute inset-0 rounded-full bg-red-500/20"
                    animate={{ scale: [1, 1.8, 1], opacity: [0.6, 0, 0.6] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  />
                  <motion.div
                    className="absolute inset-0 rounded-full bg-red-500/10"
                    animate={{ scale: [1, 2.2, 1], opacity: [0.4, 0, 0.4] }}
                    transition={{ duration: 1.5, repeat: Infinity, delay: 0.3 }}
                  />
                </>
              )}
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={handleMicToggle}
                className={`relative w-20 h-20 rounded-full flex items-center justify-center text-white transition-all duration-300 ${
                  isListening
                    ? 'bg-red-500 shadow-lg shadow-red-500/40'
                    : 'bg-gradient-to-br from-purple-600 to-violet-700 shadow-lg shadow-purple-500/40'
                }`}
              >
                {isListening ? <MicOff size={28} /> : <Mic size={28} />}
              </motion.button>
            </div>

            {/* Language */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={toggleLanguage}
              className="w-12 h-12 rounded-2xl glass-card flex items-center justify-center text-gray-400 hover:text-white transition-all"
            >
              <Globe size={20} />
            </motion.button>
          </div>
        )}

        {error && (
          <p className="text-red-400 text-xs text-center -mt-4 pb-4">{error}</p>
        )}
      </div>
    </div>
  );
};

export default VoicePage;