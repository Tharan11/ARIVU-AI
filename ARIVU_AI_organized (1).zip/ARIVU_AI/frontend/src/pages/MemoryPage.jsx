import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Brain, Target, BookOpen, Settings, Plus, Check, TrendingUp } from 'lucide-react';
import Sidebar from '../components/ui/Sidebar';
import api from '../services/api';
import toast from 'react-hot-toast';

const MemoryPage = () => {
  const [memory, setMemory] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [newGoal, setNewGoal] = useState({ title: '', description: '' });
  const [showGoalForm, setShowGoalForm] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadMemory();
  }, []);

  const loadMemory = async () => {
    try {
      const res = await api.get('/memory');
      setMemory(res.data.memory);
    } catch (err) {
      toast.error('Failed to load memory');
    } finally {
      setIsLoading(false);
    }
  };

  const addGoal = async () => {
    if (!newGoal.title.trim()) return;
    try {
      const res = await api.post('/memory/goal', newGoal);
      setMemory(prev => ({ ...prev, goals: res.data.goals }));
      setNewGoal({ title: '', description: '' });
      setShowGoalForm(false);
      toast.success('Goal added!');
    } catch (err) {
      toast.error('Failed to add goal');
    }
  };

  const completeGoal = async (goalId) => {
    try {
      await api.patch(`/memory/goal/${goalId}`, { isCompleted: true, progress: 100 });
      await loadMemory();
      toast.success('Goal completed! 🎉');
    } catch (err) {
      toast.error('Failed to update goal');
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-screen bg-ambient items-center justify-center">
        <div className="w-8 h-8 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Brain },
    { id: 'goals', label: 'Goals', icon: Target },
    { id: 'topics', label: 'Topics', icon: TrendingUp },
    { id: 'preferences', label: 'Settings', icon: Settings }
  ];

  return (
    <div className="flex h-screen bg-ambient overflow-hidden">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto p-6">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-violet-700 flex items-center justify-center">
                <Brain size={20} className="text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">AI Memory</h1>
                <p className="text-sm text-gray-500">ARIVU remembers your learning journey</p>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 mb-6">
            {tabs.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm transition-all ${
                  activeTab === id
                    ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon size={14} />
                {label}
              </button>
            ))}
          </div>

          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: 'Total Sessions', value: memory?.learningProgress?.totalSessions || 0, icon: BookOpen },
                  { label: 'Active Goals', value: memory?.goals?.filter(g => !g.isCompleted).length || 0, icon: Target },
                  { label: 'Topics Tracked', value: memory?.recurringTopics?.length || 0, icon: TrendingUp }
                ].map(({ label, value, icon: Icon }) => (
                  <div key={label} className="glass-card p-4 text-center">
                    <Icon size={20} className="text-purple-400 mx-auto mb-2" />
                    <p className="text-2xl font-bold text-white">{value}</p>
                    <p className="text-xs text-gray-500 mt-1">{label}</p>
                  </div>
                ))}
              </div>

              <div className="glass-card p-4">
                <h3 className="text-sm font-semibold text-white mb-3">Top Recurring Topics</h3>
                {memory?.recurringTopics?.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {memory.recurringTopics
                      .sort((a, b) => b.frequency - a.frequency)
                      .slice(0, 12)
                      .map(t => (
                        <span
                          key={t.topic}
                          className="px-2 py-1 rounded-lg bg-purple-600/10 border border-purple-500/20 text-xs text-purple-300"
                        >
                          {t.topic} <span className="text-purple-500">×{t.frequency}</span>
                        </span>
                      ))}
                  </div>
                ) : (
                  <p className="text-xs text-gray-600">Start chatting to build your topic profile</p>
                )}
              </div>
            </motion.div>
          )}

          {/* Goals Tab */}
          {activeTab === 'goals' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-semibold text-white">Learning Goals</h3>
                <button
                  onClick={() => setShowGoalForm(!showGoalForm)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600/20
                             border border-purple-500/30 text-purple-300 text-sm hover:bg-purple-600/30 transition-all"
                >
                  <Plus size={14} />
                  Add Goal
                </button>
              </div>

              {showGoalForm && (
                <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-4 space-y-3">
                  <input
                    type="text"
                    value={newGoal.title}
                    onChange={e => setNewGoal({ ...newGoal, title: e.target.value })}
                    placeholder="Goal title (e.g., Complete TNPSC Group 4)"
                    className="input-arivu text-sm"
                  />
                  <input
                    type="text"
                    value={newGoal.description}
                    onChange={e => setNewGoal({ ...newGoal, description: e.target.value })}
                    placeholder="Description (optional)"
                    className="input-arivu text-sm"
                  />
                  <div className="flex gap-2">
                    <button onClick={addGoal} className="btn-arivu text-sm px-4 py-2">Save Goal</button>
                    <button onClick={() => setShowGoalForm(false)} className="px-4 py-2 text-sm text-gray-400 hover:text-white transition-colors">Cancel</button>
                  </div>
                </motion.div>
              )}

              {memory?.goals?.filter(g => !g.isCompleted).length === 0 ? (
                <div className="glass-card p-8 text-center">
                  <Target size={32} className="text-gray-600 mx-auto mb-3" />
                  <p className="text-gray-500 text-sm">No active goals yet</p>
                  <p className="text-gray-600 text-xs font-tamil mt-1">இலக்கு நிர்ணயியுங்கள்</p>
                </div>
              ) : (
                memory.goals.filter(g => !g.isCompleted).map(goal => (
                  <div key={goal._id} className="glass-card p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <p className="text-sm font-medium text-white">{goal.title}</p>
                        {goal.description && <p className="text-xs text-gray-500 mt-0.5">{goal.description}</p>}
                        <div className="mt-3">
                          <div className="flex justify-between text-xs text-gray-500 mb-1">
                            <span>Progress</span>
                            <span>{goal.progress}%</span>
                          </div>
                          <div className="h-1.5 bg-arivu-border rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-purple-600 to-violet-500 rounded-full transition-all"
                              style={{ width: `${goal.progress}%` }}
                            />
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => completeGoal(goal._id)}
                        className="p-2 rounded-xl text-gray-500 hover:text-green-400 hover:bg-green-400/10 transition-all"
                        title="Mark complete"
                      >
                        <Check size={16} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </motion.div>
          )}

          {/* Topics Tab */}
          {activeTab === 'topics' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card p-6">
              <h3 className="text-sm font-semibold text-white mb-4">All Tracked Topics</h3>
              {memory?.recurringTopics?.length > 0 ? (
                <div className="space-y-2">
                  {memory.recurringTopics
                    .sort((a, b) => b.frequency - a.frequency)
                    .map(t => (
                      <div key={t.topic} className="flex items-center justify-between py-2 border-b border-arivu-border">
                        <span className="text-sm text-gray-300 capitalize">{t.topic}</span>
                        <div className="flex items-center gap-3">
                          <div className="h-1.5 w-24 bg-arivu-border rounded-full overflow-hidden">
                            <div
                              className="h-full bg-purple-600 rounded-full"
                              style={{ width: `${Math.min((t.frequency / 10) * 100, 100)}%` }}
                            />
                          </div>
                          <span className="text-xs text-purple-400 w-8 text-right">{t.frequency}×</span>
                        </div>
                      </div>
                    ))}
                </div>
              ) : (
                <p className="text-gray-600 text-sm text-center py-8">No topics tracked yet. Start chatting!</p>
              )}
            </motion.div>
          )}

          {/* Preferences Tab */}
          {activeTab === 'preferences' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card p-6 space-y-4">
              <h3 className="text-sm font-semibold text-white">Your Preferences</h3>
              <div>
                <label className="block text-xs text-gray-400 mb-1.5">Response Language</label>
                <p className="text-sm text-gray-300 capitalize">{memory?.preferences?.language || 'mixed'}</p>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1.5">Response Style</label>
                <p className="text-sm text-gray-300 capitalize">{memory?.preferences?.responseStyle || 'detailed'}</p>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1.5">Interests</label>
                <div className="flex flex-wrap gap-2">
                  {memory?.preferences?.interests?.length > 0 ? (
                    memory.preferences.interests.map(i => (
                      <span key={i} className="px-2 py-1 rounded-lg bg-purple-600/10 text-xs text-purple-300">{i}</span>
                    ))
                  ) : (
                    <p className="text-xs text-gray-600">No interests set yet</p>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MemoryPage;