import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Sparkles } from 'lucide-react';
import useAuthStore from '../store/authStore';
import toast from 'react-hot-toast';

const AuthPage = () => {
  const [mode, setMode] = useState('login');
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', password: '', preferredLanguage: 'mixed' });
  const { login, register, isLoading } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    let result;

    if (mode === 'login') {
      result = await login(form.email, form.password);
    } else {
      result = await register(form.name, form.email, form.password, form.preferredLanguage);
    }

    if (result.success) {
      toast.success(mode === 'login' ? 'வணக்கம்! Welcome back!' : 'Account created! Welcome to ARIVU!');
      navigate('/chat');
    } else {
      toast.error(result.error);
    }
  };

  return (
    <div className="min-h-screen bg-ambient flex items-center justify-center p-4">
      {/* Background glyphs */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none select-none opacity-5">
        {['அ','ஆ','இ','ஈ','உ','ஊ','எ','ஏ','ஐ','ஒ','ஓ','ஔ'].map((glyph, i) => (
          <div
            key={i}
            className="absolute text-6xl text-purple-400 font-tamil"
            style={{
              top: `${(i * 8) % 100}%`,
              left: `${(i * 8.7) % 100}%`,
              transform: `rotate(${i * 30}deg)`
            }}
          >
            {glyph}
          </div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <motion.div
            animate={{ boxShadow: ['0 0 20px rgba(124,111,255,0.3)', '0 0 50px rgba(124,111,255,0.6)', '0 0 20px rgba(124,111,255,0.3)'] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="w-20 h-20 rounded-2xl bg-gradient-to-br from-purple-600 to-violet-700
                       flex items-center justify-center text-4xl font-black text-white font-orbitron mx-auto mb-4"
          >
            அ
          </motion.div>
          <h1 className="text-3xl font-black text-white font-orbitron tracking-wider">ARIVU</h1>
          <p className="text-purple-400 font-tamil mt-1 text-lg">அறிவே வல்லமை</p>
          <p className="text-gray-500 text-sm mt-1">Tamil AI Platform</p>
        </div>

        {/* Card */}
        <div className="glass-card p-6">
          {/* Mode Toggle */}
          <div className="flex rounded-xl bg-arivu-dark/50 p-1 mb-6">
            {['login', 'register'].map(m => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  mode === m ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'
                }`}
              >
                {m === 'login' ? 'Login' : 'Register'}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <AnimatePresence mode="wait">
              {mode === 'register' && (
                <motion.div
                  key="name"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                >
                  <label className="block text-xs text-gray-400 mb-1.5">Full Name</label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={e => setForm({ ...form, name: e.target.value })}
                    placeholder="உங்கள் பெயர்"
                    required={mode === 'register'}
                    className="input-arivu font-tamil"
                  />
                </motion.div>
              )}
            </AnimatePresence>

            <div>
              <label className="block text-xs text-gray-400 mb-1.5">Email</label>
              <input
                type="email"
                value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                placeholder="you@example.com"
                required
                className="input-arivu"
              />
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1.5">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={form.password}
                  onChange={e => setForm({ ...form, password: e.target.value })}
                  placeholder="••••••••"
                  required
                  className="input-arivu pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <AnimatePresence mode="wait">
              {mode === 'register' && (
                <motion.div
                  key="lang"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                >
                  <label className="block text-xs text-gray-400 mb-1.5">Preferred Language</label>
                  <select
                    value={form.preferredLanguage}
                    onChange={e => setForm({ ...form, preferredLanguage: e.target.value })}
                    className="input-arivu"
                  >
                    <option value="mixed">Tamil + English (Mixed)</option>
                    <option value="tamil">Tamil Only - தமிழ் மட்டும்</option>
                    <option value="english">English Only</option>
                  </select>
                </motion.div>
              )}
            </AnimatePresence>

            <button
              type="submit"
              disabled={isLoading}
              className="btn-arivu w-full flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Sparkles size={16} />
                  {mode === 'login' ? 'Login to ARIVU' : 'Create Account'}
                </>
              )}
            </button>
          </form>

          <p className="text-center text-xs text-gray-600 mt-4">
            {mode === 'login' ? "Don't have an account? " : "Already have an account? "}
            <button
              onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
              className="text-purple-400 hover:text-purple-300 font-medium"
            >
              {mode === 'login' ? 'Register' : 'Login'}
            </button>
          </p>
        </div>

        <p className="text-center text-xs text-gray-700 mt-4">
          50 free queries · No credit card needed
        </p>
      </motion.div>
    </div>
  );
};

export default AuthPage;