import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Search, Loader } from 'lucide-react';
import Sidebar from '../components/ui/Sidebar';
import ReactMarkdown from 'react-markdown';
import api from '../services/api';
import toast from 'react-hot-toast';

const categories = [
  { id: 'thirukkural', label: 'திருக்குறள்', sublabel: 'Thirukkural', emoji: '📜' },
  { id: 'sangam', label: 'சங்க இலக்கியம்', sublabel: 'Sangam Literature', emoji: '🏛️' },
  { id: 'tnpsc', label: 'தேர்வு தயாரிப்பு', sublabel: 'TNPSC Prep', emoji: '📚' },
  { id: 'tamilHistory', label: 'தமிழர் வரலாறு', sublabel: 'Tamil History', emoji: '⚔️' }
];

const sampleQuestions = {
  thirukkural: ['What does Kural 1 mean?', 'Explain the concept of அறம் in Thirukkural', 'Which kurals deal with friendship?'],
  sangam: ['What are the 5 tinais in Sangam poetry?', 'Tell me about Purananuru', 'What is akam literature?'],
  tnpsc: ['TNPSC Group 4 syllabus breakdown', 'Tamil Nadu history topics for TNPSC', 'How to prepare for Group 2?'],
  tamilHistory: ['Tell me about the Chola Navy', 'What was the Pallava contribution to art?', 'Explain Sangam age economy']
};

const KnowledgePage = () => {
  const [selectedCategory, setSelectedCategory] = useState('thirukkural');
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleQuery = async (q = query) => {
    if (!q.trim()) return;
    setIsLoading(true);
    setResponse('');

    try {
      const res = await api.post('/rag/query', { query: q, category: selectedCategory });
      setResponse(res.data.response);
      setQuery(q);
    } catch (err) {
      toast.error('Query failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-ambient overflow-hidden">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto p-6">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                <BookOpen size={20} className="text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Tamil Knowledge Base</h1>
                <p className="text-sm text-gray-500">தமிழ் அறிவு களஞ்சியம்</p>
              </div>
            </div>
          </div>

          {/* Category Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`p-3 rounded-xl text-left transition-all duration-200 ${
                  selectedCategory === cat.id
                    ? 'bg-amber-500/20 border border-amber-500/50'
                    : 'glass-card hover:border-amber-500/30'
                }`}
              >
                <div className="text-2xl mb-1">{cat.emoji}</div>
                <p className="text-xs font-semibold text-white font-tamil leading-tight">{cat.label}</p>
                <p className="text-xs text-gray-500 mt-0.5">{cat.sublabel}</p>
              </button>
            ))}
          </div>

          {/* Sample Questions */}
          <div className="mb-4">
            <p className="text-xs text-gray-500 mb-2">Sample questions:</p>
            <div className="flex flex-wrap gap-2">
              {sampleQuestions[selectedCategory]?.map(q => (
                <button
                  key={q}
                  onClick={() => { setQuery(q); handleQuery(q); }}
                  className="text-xs px-3 py-1.5 rounded-lg bg-white/5 border border-white/10
                             text-gray-400 hover:text-white hover:border-amber-500/30 transition-all"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* Search Bar */}
          <div className="flex gap-3 mb-6">
            <div className="flex-1 glass-card flex items-center gap-3 px-4 py-3">
              <Search size={16} className="text-gray-500 flex-shrink-0" />
              <input
                type="text"
                value={query}
                onChange={e => setQuery(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleQuery()}
                placeholder="கேளுங்கள்... Ask about Tamil literature, history, TNPSC..."
                className="flex-1 bg-transparent text-sm text-white placeholder-gray-600 outline-none font-tamil"
              />
            </div>
            <button
              onClick={() => handleQuery()}
              disabled={!query.trim() || isLoading}
              className="btn-arivu px-5 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {isLoading ? <Loader size={16} className="animate-spin" /> : <Search size={16} />}
            </button>
          </div>

          {/* Response */}
          {isLoading && (
            <div className="glass-card p-6 flex items-center gap-3">
              <div className="w-5 h-5 border-2 border-purple-600 border-t-transparent rounded-full animate-spin" />
              <p className="text-sm text-gray-400">Searching Tamil knowledge base...</p>
            </div>
          )}

          {response && !isLoading && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-card p-6"
            >
              <div className="flex items-center gap-2 mb-4 pb-3 border-b border-arivu-border">
                <span className="text-lg">{categories.find(c => c.id === selectedCategory)?.emoji}</span>
                <div>
                  <p className="text-sm font-medium text-white">{query}</p>
                  <p className="text-xs text-gray-500">{categories.find(c => c.id === selectedCategory)?.sublabel}</p>
                </div>
              </div>
              <ReactMarkdown
                className="prose prose-invert prose-sm max-w-none
                           prose-p:my-2 prose-headings:text-amber-400
                           prose-strong:text-white prose-a:text-amber-400"
              >
                {response}
              </ReactMarkdown>
            </motion.div>
          )}

          {!response && !isLoading && (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">📚</div>
              <p className="text-gray-500 text-sm">Select a category and ask a question</p>
              <p className="text-gray-600 text-xs font-tamil mt-1">ஒரு வகையை தேர்ந்தெடுத்து கேளுங்கள்</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default KnowledgePage;