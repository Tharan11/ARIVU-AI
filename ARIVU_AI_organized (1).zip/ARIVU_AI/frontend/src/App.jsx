import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import useAuthStore from './store/authStore';
import AuthPage from './pages/AuthPage';
import ChatPage from './pages/ChatPage';
import KnowledgePage from './pages/KnowledgePage';
import MemoryPage from './pages/MemoryPage';
import VoicePage from './pages/VoicePage';
import Sidebar from './components/ui/Sidebar';

const ProtectedLayout = ({ children }) => {
  const { user } = useAuthStore();
  if (!user) return <Navigate to="/login" replace />;
  return (
    <div className="flex h-screen bg-arivu-dark overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-hidden">
        {children}
      </main>
    </div>
  );
};

const App = () => {
  return (
    <Routes>
      <Route path="/login" element={<AuthPage />} />
      <Route
        path="/chat"
        element={
          <ProtectedLayout>
            <ChatPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/knowledge"
        element={
          <ProtectedLayout>
            <KnowledgePage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/memory"
        element={
          <ProtectedLayout>
            <MemoryPage />
          </ProtectedLayout>
        }
      />
      <Route
        path="/voice"
        element={
          <ProtectedLayout>
            <VoicePage />
          </ProtectedLayout>
        }
      />
      <Route path="/" element={<Navigate to="/chat" replace />} />
      <Route path="*" element={<Navigate to="/chat" replace />} />
    </Routes>
  );
};

export default App;
