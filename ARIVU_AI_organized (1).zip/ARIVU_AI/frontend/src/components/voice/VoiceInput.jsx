import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, MicOff, Volume2, VolumeX, Globe } from 'lucide-react';
import useVoice from '../../hooks/useVoice';

const VoiceInput = ({ onTranscriptReady, onSpeak, textToSpeak, disabled }) => {
  const {
    isListening,
    isSpeaking,
    transcript,
    interimTranscript,
    voiceLanguage,
    isSupported,
    error,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
    toggleLanguage,
    clearTranscript
  } = useVoice();

  // When transcript is finalized, send it up
  useEffect(() => {
    if (transcript && !isListening) {
      onTranscriptReady(transcript);
      clearTranscript();
    }
  }, [transcript, isListening]);

  // Speak AI response when textToSpeak changes
  useEffect(() => {
    if (textToSpeak && onSpeak) {
      speak(textToSpeak);
    }
  }, [textToSpeak]);

  if (!isSupported) {
    return (
      <div className="flex items-center gap-2 text-xs text-gray-500 px-2">
        <MicOff size={14} />
        <span>Voice requires Chrome browser</span>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      {/* Language Toggle */}
      <button
        onClick={toggleLanguage}
        className="flex items-center gap-1 px-2 py-1.5 rounded-lg text-xs text-gray-400
                   hover:text-white hover:bg-white/5 transition-all duration-200"
        title={`Switch to ${voiceLanguage === 'ta-IN' ? 'English' : 'Tamil'}`}
      >
        <Globe size={13} />
        <span>{voiceLanguage === 'ta-IN' ? 'தமிழ்' : 'ENG'}</span>
      </button>

      {/* TTS Button */}
      {isSpeaking ? (
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={stopSpeaking}
          className="p-2 rounded-xl bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 transition-all"
          title="Stop speaking"
        >
          <VolumeX size={16} />
        </motion.button>
      ) : (
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => textToSpeak && speak(textToSpeak)}
          disabled={!textToSpeak}
          className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-white/5
                     disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          title="Read aloud"
        >
          <Volume2 size={16} />
        </motion.button>
      )}

      {/* Mic Button */}
      <div className="relative">
        {isListening && (
          <motion.div
            className="absolute inset-0 rounded-xl bg-red-500/30"
            animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
        )}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={isListening ? stopListening : startListening}
          disabled={disabled}
          className={`relative p-2 rounded-xl font-medium transition-all duration-200 ${
            isListening
              ? 'bg-red-500/20 text-red-400 voice-recording'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
          } disabled:opacity-30 disabled:cursor-not-allowed`}
          title={isListening ? 'Stop recording' : `Start voice input (${voiceLanguage === 'ta-IN' ? 'Tamil' : 'English'})`}
        >
          {isListening ? <MicOff size={16} /> : <Mic size={16} />}
        </motion.button>
      </div>

      {/* Interim transcript preview */}
      <AnimatePresence>
        {(isListening && interimTranscript) && (
          <motion.div
            initial={{ opacity: 0, width: 0 }}
            animate={{ opacity: 1, width: 'auto' }}
            exit={{ opacity: 0, width: 0 }}
            className="max-w-32 text-xs text-gray-400 truncate italic"
          >
            {interimTranscript}...
          </motion.div>
        )}
      </AnimatePresence>

      {/* Error */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-xs text-red-400 max-w-40 truncate"
            title={error}
          >
            {error}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default VoiceInput;