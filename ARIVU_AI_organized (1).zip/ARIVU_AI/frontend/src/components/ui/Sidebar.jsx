import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, MessageSquare, Trash2, Brain, Mic, BookOpen, LogOut, X, Zap } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import useChatStore from '../../store/chatStore';
import useAuthStore from '../../store/authStore';
import { formatDistanceToNow } from 'date-fns';

const Sidebar = ({ isOpen, onClose }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { conversations, loadConversations, loadConversation, startNewConversation, deleteConversation, activeConversation } = useChatStore();
  const { user, logout } = useAuthStore();

  useEffect(() => {
    loadConversations();
  }, []);

  const handleNewChat = () => {
    startNewConversation();
    navigate('/chat');
    onClose?.();
  };

  const handleSelectConversation = (id) => {
    loadConversation(id);
    navigate('/chat');
    onClose?.();
  };

  const navItems = [
    { icon: MessageSquare, label: 'Chat', path: '/chat' },
    { icon: Brain, label: 'Memory', path: '/memory' },
    { icon: BookOpen, label: 'Tamil Knowledge', path: '/knowledge' },
    { icon: Mic, label: 'Voice Mode', path: '/voice' }
  ];

  const sidebarContent = (
    <div className="h-full flex flex-col bg-arivu-card border-r border-arivu-border">
      {/* Header */}
      <div className="p-4 border-b border-arivu-border flex items-center justify-between">
        <div>
          <h1 className="text-lg font-black text-white font-orbitron tracking-wider">ARIVU</h1>
          <p className="text-xs text-purple-400 font-tamil">அறிவு AI</p>
        </div>
        <div className="flex items-center gap-2">
          {user?.credits !== undefined && (
            <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-purple-600/10 border border-purple-500/20">
              <Zap size={11} className="text-purple-400" />
              <span className="text-xs text-purple-300">{user.credits}</span>
            </div>
          )}
          {onClose && (
            <button onClick={onClose} className="p-1 text-gray-500 hover:text-white lg:hidden">
              <X size={18} />
            </button>
          )}
        </div>
      </div>

      {/* New Chat Button */}
      <div className="p-3">
        <button
          onClick={handleNewChat}
          className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl
                     bg-gradient-to-r from-purple-600/20 to-violet-600/20
                     border border-purple-500/30 text-purple-300
                     hover:from-purple-600/30 hover:to-violet-600/30
                     transition-all duration-200 text-sm font-medium"
        >
          <Plus size={16} />
          <span>New Chat</span>
        </button>
      </div>

      {/* Nav Items */}
      <div className="px-3 pb-2">
        {navItems.map(({ icon: Icon, label, path }) => (
          <button
            key={path}
            onClick={() => { navigate(path); onClose?.(); }}
            className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-sm
                        transition-all duration-200 mb-0.5 text-left ${
              location.pathname === path
                ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Icon size={15} />
            <span>{label}</span>
          </button>
        ))}
      </div>

      {/* Conversations */}
      <div className="flex-1 overflow-y-auto chat-scroll px-3 pb-2">
        <p className="text-xs text-gray-600 uppercase tracking-wider px-2 mb-2">Recent Chats</p>
        <AnimatePresence>
          {conversations.map(conv => (
            <motion.div
              key={conv._id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              className={`group flex items-center gap-2 px-3 py-2 rounded-xl cursor-pointer
                          transition-all duration-200 mb-0.5 ${
                activeConversation?._id === conv._id
                  ? 'bg-purple-600/15 border border-purple-500/20'
                  : 'hover:bg-white/5'
              }`}
              onClick={() => handleSelectConversation(conv._id)}
            >
              <MessageSquare size={13} className={activeConversation?._id === conv._id ? 'text-purple-400' : 'text-gray-600'} />
              <div className="flex-1 min-w-0">
                <p className="text-xs text-gray-300 truncate">{conv.title}</p>
                <p className="text-xs text-gray-600">
                  {formatDistanceToNow(new Date(conv.updatedAt), { addSuffix: true })}
                </p>
              </div>
              <button
                onClick={e => { e.stopPropagation(); deleteConversation(conv._id); }}
                className="opacity-0 group-hover:opacity-100 p-1 text-gray-600 hover:text-red-400 transition-all"
              >
                <Trash2 size={12} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>

        {conversations.length === 0 && (
          <div className="text-center py-8">
            <p className="text-xs text-gray-600">No conversations yet</p>
            <p className="text-xs text-gray-700 font-tamil mt-1">உரையாடல் தொடங்குங்கள்</p>
          </div>
        )}
      </div>

      {/* User Footer */}
      <div className="p-3 border-t border-arivu-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-purple-600 to-violet-700
                          flex items-center justify-center text-sm font-bold text-white">
            {user?.name?.[0]?.toUpperCase() || 'U'}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm text-white font-medium truncate">{user?.name}</p>
            <p className="text-xs text-gray-500 capitalize">{user?.plan} plan</p>
          </div>
          <button
            onClick={logout}
            className="p-1.5 text-gray-500 hover:text-red-400 rounded-lg hover:bg-red-400/10 transition-all"
            title="Logout"
          >
            <LogOut size={15} />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <div className="hidden lg:block w-64 flex-shrink-0 h-full">
        {sidebarContent}
      </div>

      {/* Mobile drawer */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-40 lg:hidden"
              onClick={onClose}
            />
            <motion.div
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 bottom-0 w-72 z-50 lg:hidden"
            >
              {sidebarContent}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default Sidebar;