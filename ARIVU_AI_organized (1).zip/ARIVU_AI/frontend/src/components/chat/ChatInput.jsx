import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Send, Sparkles } from 'lucide-react';
import VoiceInput from '../voice/VoiceInput';
import useChatStore from '../../store/chatStore';
import toast from 'react-hot-toast';

const ChatInput = ({ lastAIMessage, onSpeak }) => {
  const [input, setInput] = useState('');
  const { sendMessage, isTyping, selectedModel, setSelectedModel } = useChatStore();
  const textareaRef = useRef(null);

  const models = [
    { id: 'gemini', label: 'Gemini', color: 'blue' },
    { id: 'groq', label: 'Groq', color: 'green' },
    { id: 'openai', label: 'GPT', color: 'teal' }
  ];

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 160)}px`;
    }
  }, [input]);

  const handleSend = async () => {
    const trimmed = input.trim();
    if (!trimmed || isTyping) return;

    setInput('');
    try {
      await sendMessage(trimmed);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to send message');
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleVoiceTranscript = (transcript) => {
    setInput(prev => (prev ? prev + ' ' : '') + transcript);
    textareaRef.current?.focus();
  };

  return (
    <div className="border-t border-arivu-border bg-arivu-dark/95 backdrop-blur-md p-4 safe-bottom">
      {/* Model Selector */}
      <div className="flex items-center gap-2 mb-3">
        <Sparkles size={13} className="text-purple-400" />
        <span className="text-xs text-gray-500">Model:</span>
        {models.map(m => (
          <button
            key={m.id}
            onClick={() => setSelectedModel(m.id)}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
              selectedModel === m.id
                ? 'bg-purple-600/30 text-purple-300 border border-purple-500/50'
                : 'text-gray-500 hover:text-gray-300 hover:bg-white/5'
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      {/* Input Row */}
      <div className="flex items-end gap-3">
        <div className="flex-1 glass-card p-1 flex items-end gap-2">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="கேளுங்கள்... Ask ARIVU anything in Tamil or English..."
            rows={1}
            disabled={isTyping}
            className="flex-1 bg-transparent text-sm text-white placeholder-gray-600
                       resize-none outline-none px-3 py-2.5 leading-relaxed
                       font-tamil disabled:opacity-50 max-h-40"
            style={{ minHeight: '44px' }}
          />

          <div className="flex items-center gap-1 pb-1 pr-1">
            <VoiceInput
              onTranscriptReady={handleVoiceTranscript}
              onSpeak={onSpeak}
              textToSpeak={lastAIMessage}
              disabled={isTyping}
            />
          </div>
        </div>

        {/* Send Button */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={handleSend}
          disabled={!input.trim() || isTyping}
          className="p-3 rounded-xl bg-gradient-to-br from-purple-600 to-violet-700 text-white
                     disabled:opacity-40 disabled:cursor-not-allowed
                     hover:shadow-lg transition-all duration-200 flex-shrink-0"
          style={{ boxShadow: input.trim() ? '0 0 20px rgba(124, 111, 255, 0.4)' : 'none' }}
        >
          <Send size={18} />
        </motion.button>
      </div>

      <p className="text-center text-xs text-gray-700 mt-2">
        Press <kbd className="px-1 py-0.5 bg-white/5 rounded text-gray-600 font-mono text-xs">Enter</kbd> to send
        · <kbd className="px-1 py-0.5 bg-white/5 rounded text-gray-600 font-mono text-xs">Shift+Enter</kbd> for new line
      </p>
    </div>
  );
};

export default ChatInput;