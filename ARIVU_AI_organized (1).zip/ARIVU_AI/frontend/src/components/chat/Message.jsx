import React, { useState } from 'react';
import { motion } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Copy, Check, Volume2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const Message = ({ message, onSpeak, isLatestAI }) => {
  const [copied, setCopied] = useState(false);
  const isAI = message.role === 'assistant';

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`flex gap-3 ${isAI ? '' : 'flex-row-reverse'} group`}
    >
      {/* Avatar */}
      <div className={`flex-shrink-0 w-8 h-8 rounded-xl flex items-center justify-center text-sm font-bold ${
        isAI
          ? 'bg-gradient-to-br from-purple-600 to-violet-700 text-white'
          : 'bg-gradient-to-br from-slate-600 to-slate-700 text-gray-200'
      }`}>
        {isAI ? 'அ' : 'U'}
      </div>

      {/* Bubble */}
      <div className={`flex-1 max-w-[80%] ${isAI ? '' : 'flex flex-col items-end'}`}>
        <div className={`rounded-2xl px-4 py-3 ${
          isAI
            ? 'bg-arivu-card message-ai text-gray-100'
            : 'bg-gradient-to-br from-purple-600/80 to-violet-700/80 text-white'
        }`}>
          {isAI ? (
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              className="prose prose-invert prose-sm max-w-none
                         prose-p:my-1 prose-headings:text-purple-300
                         prose-code:text-purple-300 prose-pre:p-0 prose-pre:bg-transparent
                         prose-ul:my-1 prose-ol:my-1 prose-li:my-0.5
                         prose-strong:text-white prose-a:text-purple-400"
              components={{
                code({ node, className, children, ...props }) {
                  const match = /language-(\w+)/.exec(className || '');
                  return match ? (
                    <SyntaxHighlighter
                      style={oneDark}
                      language={match[1]}
                      PreTag="div"
                      className="rounded-xl text-xs my-2"
                      {...props}
                    >
                      {String(children).replace(/\n$/, '')}
                    </SyntaxHighlighter>
                  ) : (
                    <code className="bg-black/30 px-1.5 py-0.5 rounded text-purple-300 text-sm" {...props}>
                      {children}
                    </code>
                  );
                }
              }}
            >
              {message.content}
            </ReactMarkdown>
          ) : (
            <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
          )}
        </div>

        {/* Actions row */}
        <div className={`flex items-center gap-2 mt-1 px-1 opacity-0 group-hover:opacity-100 transition-opacity ${isAI ? '' : 'flex-row-reverse'}`}>
          <span className="text-xs text-gray-600">
            {message.timestamp
              ? formatDistanceToNow(new Date(message.timestamp), { addSuffix: true })
              : ''}
          </span>

          {isAI && (
            <>
              <button
                onClick={copyToClipboard}
                className="p-1 rounded text-gray-500 hover:text-white transition-colors"
                title="Copy message"
              >
                {copied ? <Check size={12} className="text-green-400" /> : <Copy size={12} />}
              </button>

              <button
                onClick={() => onSpeak(message.content)}
                className="p-1 rounded text-gray-500 hover:text-white transition-colors"
                title="Read aloud"
              >
                <Volume2 size={12} />
              </button>
            </>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default Message;