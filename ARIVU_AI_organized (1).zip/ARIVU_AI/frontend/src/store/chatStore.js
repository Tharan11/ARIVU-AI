import { create } from 'zustand';
import api from '../services/api';

const useChatStore = create((set, get) => ({
  conversations: [],
  activeConversation: null,
  messages: [],
  isLoading: false,
  isTyping: false,
  selectedModel: 'gemini',
  selectedLanguage: 'mixed',

  setSelectedModel: (model) => set({ selectedModel: model }),
  setSelectedLanguage: (lang) => set({ selectedLanguage: lang }),

  loadConversations: async () => {
    try {
      const res = await api.get('/chat/conversations');
      set({ conversations: res.data.conversations });
    } catch (err) {
      console.error('Failed to load conversations:', err);
    }
  },

  loadConversation: async (id) => {
    try {
      set({ isLoading: true });
      const res = await api.get(`/chat/conversations/${id}`);
      const conv = res.data.conversation;
      set({
        activeConversation: conv,
        messages: conv.messages,
        isLoading: false
      });
    } catch (err) {
      set({ isLoading: false });
    }
  },

  sendMessage: async (content) => {
    const { activeConversation, selectedModel, selectedLanguage, messages } = get();

    // Optimistic update
    const userMsg = { role: 'user', content, timestamp: new Date() };
    set(state => ({ messages: [...state.messages, userMsg], isTyping: true }));

    try {
      const res = await api.post('/chat/message', {
        message: content,
        conversationId: activeConversation?._id,
        model: selectedModel,
        language: selectedLanguage
      });

      const { conversationId, response } = res.data;
      const aiMsg = { role: 'assistant', content: response, timestamp: new Date() };

      set(state => ({
        messages: [...state.messages, aiMsg],
        isTyping: false,
        activeConversation: state.activeConversation || { _id: conversationId }
      }));

      // Refresh conversations list
      get().loadConversations();

      return { success: true, conversationId };
    } catch (err) {
      set(state => ({
        messages: state.messages.slice(0, -1),
        isTyping: false
      }));
      throw err;
    }
  },

  startNewConversation: () => {
    set({ activeConversation: null, messages: [] });
  },

  deleteConversation: async (id) => {
    try {
      await api.delete(`/chat/conversations/${id}`);
      set(state => ({
        conversations: state.conversations.filter(c => c._id !== id),
        activeConversation: state.activeConversation?._id === id ? null : state.activeConversation,
        messages: state.activeConversation?._id === id ? [] : state.messages
      }));
    } catch (err) {
      console.error('Delete failed:', err);
    }
  }
}));

export default useChatStore;
# ========================================
# ARIVU AI - Backend Environment Variables
# ========================================

# Server
PORT=5000
NODE_ENV=development

# MongoDB Atlas
MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/arivu_ai?retryWrites=true&w=majority

# JWT Secret (use a long random string)
JWT_SECRET=your_super_secret_jwt_key_minimum_32_chars

# AI API Keys
GEMINI_API_KEY=your_google_gemini_api_key_here
GROQ_API_KEY=your_groq_api_key_here
OPENAI_API_KEY=your_openai_api_key_here

# Frontend URL (for CORS)
FRONTEND_URL=http://localhost:5173

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX=100
/* ============================================================
   ARIVU AI - src/styles/index.css
   ============================================================ */
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }

  html {
    scroll-behavior: smooth;
  }

  body {
    background-color: #0a0a0f;
    color: #e2e8f0;
    font-family: 'DM Sans', sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    min-height: 100vh;
    overflow-x: hidden;
  }

  /* Tamil text rendering */
  .tamil-text {
    font-family: 'Noto Sans Tamil', sans-serif;
    line-height: 1.8;
  }
}

@layer components {
  /* Glassmorphism card */
  .glass-card {
    background: rgba(18, 18, 26, 0.8);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    border: 1px solid rgba(124, 111, 255, 0.15);
    border-radius: 16px;
  }

  /* Glow button */
  .btn-arivu {
    @apply bg-gradient-to-r from-purple-600 to-violet-600 text-white font-semibold
           px-6 py-3 rounded-xl transition-all duration-200
           hover:shadow-lg hover:scale-105 active:scale-95;
    box-shadow: 0 0 20px rgba(124, 111, 255, 0.3);
  }

  .btn-arivu:hover {
    box-shadow: 0 0 40px rgba(124, 111, 255, 0.5);
  }

  /* Input field */
  .input-arivu {
    @apply w-full bg-arivu-card border border-arivu-border rounded-xl px-4 py-3
           text-white placeholder-arivu-muted
           focus:outline-none focus:border-arivu-purple transition-colors duration-200;
  }

  /* Scrollbar */
  .chat-scroll::-webkit-scrollbar {
    width: 4px;
  }
  .chat-scroll::-webkit-scrollbar-track {
    background: transparent;
  }
  .chat-scroll::-webkit-scrollbar-thumb {
    background: rgba(124, 111, 255, 0.3);
    border-radius: 4px;
  }
  .chat-scroll::-webkit-scrollbar-thumb:hover {
    background: rgba(124, 111, 255, 0.6);
  }

  /* Ambient background glow */
  .bg-ambient {
    background: radial-gradient(ellipse at 20% 50%, rgba(124, 111, 255, 0.05) 0%, transparent 60%),
                radial-gradient(ellipse at 80% 20%, rgba(167, 139, 250, 0.05) 0%, transparent 60%),
                #0a0a0f;
  }

  /* Voice recording animation */
  @keyframes voicePulse {
    0%, 100% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.3); opacity: 0.7; }
  }
  .voice-recording {
    animation: voicePulse 1s ease-in-out infinite;
  }

  /* Typing indicator */
  @keyframes typingDot {
    0%, 100% { opacity: 0.3; transform: translateY(0); }
    50% { opacity: 1; transform: translateY(-4px); }
  }
  .typing-dot {
    animation: typingDot 1.2s ease-in-out infinite;
  }
  .typing-dot:nth-child(2) { animation-delay: 0.2s; }
  .typing-dot:nth-child(3) { animation-delay: 0.4s; }

  /* Message bubble glow */
  .message-ai {
    border-left: 2px solid rgba(124, 111, 255, 0.5);
    box-shadow: inset 0 0 20px rgba(124, 111, 255, 0.03);
  }
}

/* PWA safe area */
@supports (padding: env(safe-area-inset-bottom)) {
  .safe-bottom {
    padding-bottom: env(safe-area-inset-bottom);
  }
}
<!DOCTYPE html>
<html lang="ta">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/arivu-icon.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="ARIVU AI - Tamil AI Platform for Knowledge and Learning" />
    <meta name="theme-color" content="#7c6fff" />

    <!-- PWA Manifest -->
    <link rel="manifest" href="/manifest.json" />

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=DM+Sans:wght@300;400;500;700&family=Noto+Sans+Tamil:wght@300;400;500;700&display=swap" rel="stylesheet" />

    <title>ARIVU AI — அறிவு</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>