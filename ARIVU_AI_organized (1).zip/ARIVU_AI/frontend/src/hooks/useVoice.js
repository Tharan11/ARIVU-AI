import { useState, useRef, useCallback, useEffect } from 'react';
import api from '../services/api';

const useVoice = () => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [voiceLanguage, setVoiceLanguage] = useState('ta-IN'); // Tamil by default
  const [isSupported, setIsSupported] = useState(false);
  const [error, setError] = useState(null);

  const recognitionRef = useRef(null);
  const synthRef = useRef(window.speechSynthesis);
  const utteranceRef = useRef(null);

  // Check browser support
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    setIsSupported(!!SpeechRecognition && !!window.speechSynthesis);
  }, []);

  // Initialize speech recognition
  const initRecognition = useCallback(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return null;

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = voiceLanguage;
    recognition.maxAlternatives = 3;

    recognition.onstart = () => {
      setIsListening(true);
      setError(null);
      setTranscript('');
      setInterimTranscript('');
    };

    recognition.onresult = (event) => {
      let interim = '';
      let final = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        if (result.isFinal) {
          final += result[0].transcript;
        } else {
          interim += result[0].transcript;
        }
      }

      if (final) setTranscript(prev => prev + final);
      setInterimTranscript(interim);
    };

    recognition.onerror = (event) => {
      setIsListening(false);
      if (event.error === 'not-allowed') {
        setError('Microphone permission denied. Please allow microphone access.');
      } else if (event.error === 'no-speech') {
        setError('No speech detected. Please try again.');
      } else {
        setError(`Voice error: ${event.error}`);
      }
    };

    recognition.onend = () => {
      setIsListening(false);
      setInterimTranscript('');
    };

    return recognition;
  }, [voiceLanguage]);

  // Start listening
  const startListening = useCallback(() => {
    if (!isSupported) {
      setError('Voice recognition not supported in this browser. Please use Chrome.');
      return;
    }

    if (isSpeaking) {
      stopSpeaking();
    }

    recognitionRef.current = initRecognition();
    if (recognitionRef.current) {
      try {
        recognitionRef.current.start();
      } catch (err) {
        setError('Failed to start voice recognition');
      }
    }
  }, [isSupported, isSpeaking, initRecognition, stopSpeaking]);

  // Stop listening
  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsListening(false);
  }, []);

  // Speak text in Tamil or English
  const speak = useCallback((text, lang = null) => {
    if (!window.speechSynthesis) return;

    synthRef.current.cancel(); // Stop any current speech

    const utterance = new SpeechSynthesisUtterance(text);
    utteranceRef.current = utterance;

    // Language selection
    const spokenLang = lang || (voiceLanguage === 'ta-IN' ? 'ta-IN' : 'en-IN');
    utterance.lang = spokenLang;
    utterance.rate = 0.9;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;

    // Try to find a Tamil voice
    const voices = synthRef.current.getVoices();
    const tamilVoice = voices.find(v => v.lang.includes('ta'));
    const indianVoice = voices.find(v => v.lang.includes('IN'));

    if (spokenLang === 'ta-IN' && tamilVoice) {
      utterance.voice = tamilVoice;
    } else if (indianVoice) {
      utterance.voice = indianVoice;
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    synthRef.current.speak(utterance);
    setIsSpeaking(true);
  }, [voiceLanguage]);

  // Stop speaking
  const stopSpeaking = useCallback(() => {
    if (synthRef.current) {
      synthRef.current.cancel();
      setIsSpeaking(false);
    }
  }, []);

  // Toggle voice language
  const toggleLanguage = useCallback(() => {
    setVoiceLanguage(prev => prev === 'ta-IN' ? 'en-IN' : 'ta-IN');
    setTranscript('');
  }, []);

  // Clear transcript
  const clearTranscript = useCallback(() => {
    setTranscript('');
    setInterimTranscript('');
  }, []);

  return {
    isListening,
    isSpeaking,
    transcript,
    interimTranscript,
    voiceLanguage,
    isSupported,
    error,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
    toggleLanguage,
    clearTranscript,
    setVoiceLanguage
  };
};

export default useVoice;