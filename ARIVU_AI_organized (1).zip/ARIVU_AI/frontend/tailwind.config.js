/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        orbitron: ['Orbitron', 'sans-serif'],
        sans: ['DM Sans', 'sans-serif'],
        tamil: ['Noto Sans Tamil', 'sans-serif']
      },
      colors: {
        arivu: {
          purple: '#7c6fff',
          dark: '#0a0a0f',
          card: '#12121a',
          border: '#1e1e2e',
          muted: '#6b7280',
          accent: '#a78bfa'
        }
      },
      animation: {
        'glow-pulse': 'glowPulse 3s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
        'shimmer': 'shimmer 2s linear infinite'
      },
      keyframes: {
        glowPulse: {
          '0%, 100%': { boxShadow: '0 0 20px rgba(124, 111, 255, 0.2)' },
          '50%': { boxShadow: '0 0 40px rgba(124, 111, 255, 0.5)' }
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' }
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' }
        }
      }
    }
  },
  plugins: []
};